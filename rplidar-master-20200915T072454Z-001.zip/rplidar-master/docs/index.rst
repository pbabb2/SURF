Welcome to RPLidar's documentation!
===================================

.. automodule:: rplidar


.. autoclass:: rplidar.RPLidar
   :members:

   .. automethod:: __init__

.. autoexception:: rplidar.RPLidarException
    :members:
    :show-inheritance:
